package com.wsbh.c.board003;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/* Todo
 * 1. 글을 수정시켜야함
 */

public class Logic {
	public static Scanner sc = new Scanner(System.in);
	public static ArrayList<Article> article = new ArrayList<>();
	
	public static String name;
	public static String value;
	public static Date date = new Date();
	
	static void run() {
		helloWorld();
		chooseMenu();
	}
	
	static void helloWorld() {
		System.out.println("-------------------------------------------");
		System.out.println("어서오세요");
		System.out.println("1번 : 글 리스트 보기 / 2번 글 작성하기 / 3번 글 삭제하기 / 4번 작성글 읽기 / 5 : 글 수정하기 / 6: 종료");
		System.out.println("-------------------------------------------");
		System.out.println("선택>");
	}
	
	static void chooseMenu() {
		boolean out = true;
		while(out) {
		int ch = Integer.parseInt(sc.nextLine());
		switch(ch) {
		case 1: 
			ProcMenuList.loadArticle(article);
			break;
		case 2: 
			ProcMenuWrite.writeArticle(article);
			break;
		case 3:
			ProcMenuDel.delArticle(article);
			break;
		case 4: 
			ProcMenuRead.readArticle(article);
			break;
		case 5:
			ProcMenuRewrite.rewriteArticle(article);
			break;
		case 6:
			System.out.println("종료");
			out = false;
			break;
		default : 
			System.out.println("잘못 입력하셨습니다.");
			chooseMenu();
			break;
		}
		run();
		}
	}
	
	
	public static class Article{
		int number;
		String name;
		String value;
		Date date;
		public Article(int number,String name, String value) {
			this.number = number;
			this.name = name;
			this.value = value;
			this.date = new Date();
		}
		
	}
}
