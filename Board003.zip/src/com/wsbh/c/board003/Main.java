package com.wsbh.c.board003;

public class Main {
	public static void main(String[] args) {
		Logic logic = new Logic();
		logic.run();
	}
}
