package com.wsbh.c.board003;
/* Todo
 * 1. 글을 삭제시켜야함 ProcMenuDel
 */

import java.util.ArrayList;

/*	문제점
 *  1. 해당 번호를 지우고 다른 번호를 입력해서 지우면 삭제가 이상해짐 
 */

public class ProcMenuDel extends Logic {
	
	static void delArticle(ArrayList<Article> article){
		System.out.println("글을 삭제하실 번호를 입력해주세요");
		int delarticlenum = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i<article.size(); i++) {
			if(delarticlenum == article.get(i).number) {
				article.remove(i);
				break;
//	문제점 1. 해당 번호를 지우고 다른 번호를 입력해서 지우면 삭제가 이상해짐
/*	어떻게 해결할까?
 * 	1. 번호 설정을 다시 해야함 ( 만드는건 굳이? )
 * 	2. 번호 지우는걸 다시 해야함 ( 
 */
			}
		}
	}
	
}
