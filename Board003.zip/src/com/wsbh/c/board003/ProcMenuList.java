package com.wsbh.c.board003;

import java.text.SimpleDateFormat;
import java.util.List;

public class ProcMenuList extends Logic {

	public static void loadArticle(List<Article> articleList) {
		for (Article article : articleList) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy년 MM월 dd일");
			System.out.printf("글 번호 : %d 작성자 : %s 작성일 : %s \n",article.number,article.name,dateFormat.format(article.date));
			System.out.println("-------------------------");
			
		}
	}

}