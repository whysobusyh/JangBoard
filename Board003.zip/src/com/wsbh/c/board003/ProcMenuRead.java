package com.wsbh.c.board003;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ProcMenuRead extends Logic {
	
	static void readArticle(ArrayList<Article> articleList) {
		System.out.println("읽고싶은 글 번호를 입력해주세요");
		int readArticleNumber = Integer.parseInt(sc.nextLine());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy년 MM월 dd일");
		for (Article article : articleList) {
			if(readArticleNumber == article.number) {
			System.out.println("글 작성자: " + article.name);
			System.out.println("내용: " + article.value);
			System.out.println("작성일: " + dateFormat.format(article.date));
			System.out.println("-------------------------");
			break;
			}
			
		}
	}
}
