package com.wsbh.c.board003;

import java.util.ArrayList;

/* Todo
 * 1. 글을 수정시켜야함
 * 2. 수정할려고 하는 글 번호를 입력하게 함
 * 3. 확인시켜줌
 * 4. 
 */


public class ProcMenuRewrite extends Logic {
	static void rewriteArticle(ArrayList<Article> articles) {
		System.out.println("수정하고 싶은 글을 입력해주세요.");
		ProcMenuList.loadArticle(article);
		int rewriteArticleNumber = Integer.parseInt(sc.nextLine());
		boolean checkRewrite = true;
		
		for(Article rewrite : article) {
			if(rewriteArticleNumber == rewrite.number) {
				System.out.printf("글 번호 : %d 작성자 : %s 을 수정합니다. 수정 내용을 입력해주세요\n", rewrite.number,rewrite.name);
				System.out.println("글 작성자: " + rewrite.name);
				System.out.println("내용 : ");
				rewrite.value = sc.nextLine();
				checkRewrite = false;
				break;
			}
		}
		
		
		if (checkRewrite == true) {
			System.out.println("일치하는 글이 없습니다.");
			while(true) {
			System.out.println("다른 글 번호를 입력하시겠습니까? 1. Y 2. N");
			int recheck = Integer.parseInt(sc.nextLine());
			switch(recheck) {
			case 1: rewriteArticle(article);
				break;
			case 2: run();
				break;
			default : 
				System.out.println("잘못 입력하셨습니다. 다시 입력해주세요");
			break;
			}
		}
		
		}
		
		
		
	}
}
