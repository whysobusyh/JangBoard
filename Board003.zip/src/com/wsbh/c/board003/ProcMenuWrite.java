package com.wsbh.c.board003;

import java.util.ArrayList;

public class ProcMenuWrite extends Logic {

	static void writeArticle(ArrayList<Article> write) {
		System.out.println("작성자 입력");
		name = sc.nextLine();
		System.out.println("글 내용");
		value = sc.nextLine();
		int articlenumber = article.size() + 1;
		
		write.add(new Article(articlenumber,name, value));

	}
}
