package Main;

/* To do
 * 1. 객체용 index들을 하나의 class 파일에 다 옮기기
 * 2. Logic에서 불러와서 실행시키기
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KioskObj {
	public static List<Menu> DrinkMenu = new ArrayList<>();
	public static List<Menu> SideMenu = new ArrayList<>();
	public static List<Menu> Basket = new ArrayList<>();
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	public static int ch;

	public static class Menu {
		int number;
		String name;
		int price;

		public Menu(int number, String name, int price) {
			this.number = number;
			this.name = name;
			this.price = price;
		}
	}

	public static void DrinkMenuLoad() {
		DrinkMenu.clear();
		DrinkMenu.add(new Menu(1, "아메리카노", 3000));
		DrinkMenu.add(new Menu(2, "카페라떼", 3500));
		DrinkMenu.add(new Menu(3, "자바칩 프라푸치노", 3800));
		DrinkMenu.add(new Menu(4, "레몬 에이드", 4000));

		for (Menu Item : DrinkMenu) {
			System.out.println(Item.number + "번 : " + Item.name + "(" + Item.price + "원)");
		}
	}

	public static void SideMenuLoad() {
		SideMenu.clear();
		SideMenu.add(new Menu(1, "바움쿠헨", 4500));
		SideMenu.add(new Menu(2, "초코 케이크", 4500));
		SideMenu.add(new Menu(3, "치즈 케이크", 4500));
		SideMenu.add(new Menu(4, "후르츠 타르트", 4500));

		for (Menu Item : SideMenu) {
			System.out.println(Item.number + "번 : " + Item.name + "(" + Item.price + "원)");
		}
	}

}
