package Main;

import java.util.List;

import Main.KioskObj.Menu;

/* To do
 * 1. 객체용 index들을 하나의 class 파일에 다 옮기기
 * 2. Logic에서 불러와서 실행시키기
 */
/* 문제점
 * 1. 하나의 파일에 다 넣으니깐 class 파일이 하나임
 */
public class Logic extends KioskObj {
	static void run() {
		HelloWorld();
		ChooseMenu();
	}

	static void HelloWorld() {
		System.out.println("어서오세요. 고객님 뉴버거카페입니다.");
	}

	static void ChooseMenu() {
		System.out.println("어느것을 주문하시겠어요?");
		System.out.println("1번 : 드링크 메뉴 / 2번 : 사이드 메뉴 / 3번 : 종료");
		cmd = sc.next();
		ch = Integer.parseInt(cmd);
		switch (ch) {
		case 1:
			DrinkMenuLoad();
			Order(DrinkMenu);
			PrintMenu(DrinkMenu);
			break;
		case 2:
			SideMenuLoad();
			Order(SideMenu);
			PrintMenu(SideMenu);
			break;
		case 3:
			System.out.println("감사합니다 고객님");
			run();
			break;
		default:
			System.out.println("잘못 입력하셨습니다");
			ChooseMenu();
			break;
		}
	}
	/*
	 * 1. order을 스위치 내에 넣는다. 안에 넣으면 order(MenuList)사용 2. order을 밖에 내놓는다.
	 * 
	 */

	static void Order(List<Menu> MenuLists) {
		System.out.println("위의 메뉴를 보시고 무엇을 구매하실지 입력해주세요.");
		cmd = sc.next();

		for (Menu menu : MenuLists) {
			if (menu.name.equals(cmd) || Integer.toString(menu.number).equals(cmd)) {
				System.out.printf("%d번 : %s 선택하셨습니다. (%d원)\n", menu.number, menu.name, menu.price);
			}
		}
	}

	public static void PrintMenu(List<Menu> MenuList) {
		System.out.println("수량을 입력해주세요");
		int quantity = 0;
		quantity = sc.nextInt();

		for (Menu Item : MenuList) {
			if (Integer.toString(Item.number).equals(cmd)) {
				System.out.println(Item.name + " 수량 : " + quantity + " 선택하셨습니다.");
				int totalCost = quantity * Item.price;
				System.out.println("가격은 " + totalCost + "원 입니다.");
				Menu currentOrder = new Menu(quantity, Item.name, totalCost);
				Basket.add(currentOrder);
			}
		}
		AdditionalOrder();
	}

	static void AdditionalOrder() {
		System.out.println("추가 주문하시겠어요?");
		System.out.println("1번 : 추가주문 / 2번 : 구매 / 3번 : 구매취소 및 종료");
		ch = sc.nextInt();
		switch (ch) {
		case 1:
			ChooseMenu();
			break;
		case 2:
			PrintOrder();
			break;
		case 3:
			System.out.println("취소 및 종료되었습니다. 초기화면으로 돌아갑니다.");
			Basket.clear();
			run();
			break;
		default:
			System.out.println("잘못 입력하셨습니다.");
			AdditionalOrder();
			break;
		}
	}

	static void PrintOrder() {
		System.out.println("고객님이 주문하신 내역입니다.");
		int totalCostSum = 0;
		for (Menu print : Basket) {
			System.out.printf("%s 수량 : %d 가격 : %d \n", print.name, print.number, print.price);
			totalCostSum += print.price;
		}
		System.out.println("총 가격은 " + totalCostSum + "원 입니다.");

	}

}
