package Main;

/* To do
 * 1. 객체용 index들을 하나의 class 파일에 다 옮기기
 * 2. Logic에서 불러와서 실행시키기
 */
public class Main {
	public static void main(String[] args) {
		Logic logic = new Logic();
		logic.run();
		
	}
}
